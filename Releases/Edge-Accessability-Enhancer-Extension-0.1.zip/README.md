# Edge extension
An Edge extension experiment to help nerodivergent folk find zen interacting with web resources.
